Tarea 3 - Diego Casas Ubilla - dacasas@uc.cl
Diseño y Análisis de Algoritmos
Versión de python - 3.5.2

Para ejecutar el programa se deben tener los archivos 'Tarea3_Diego_Casas.py', 'integer.py' y 'test_primalidad.py' en la misma carpeta. Y se debe ejecutar con el comando en consola:
python Tarea_3_Diego_Casas.py
(Procurar que el python utilizado sea 3.5.2)
En el programa se darán las opciones descritas en el enunciado.
